# your_app_name/urls.py
from django.urls import path
from .views import file_list, share_file, upload_file, search_users, display_shared_files

urlpatterns = [
    path('file_list/', file_list, name='file_list'),
    path('share_file/<int:file_id>/', share_file, name='share_file'),
    path('upload_file/', upload_file, name='upload_file'),
    path('search_users/', search_users, name='search_users'),
    path('display_shared_files/<int:user_id>/', display_shared_files, name='display_shared_files'),
]
