# your_app_name/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Q
from .models import FileUpload, UserProfile

@login_required
def file_list(request):
    user_files = FileUpload.objects.filter(user=request.user)
    shared_files = FileUpload.objects.filter(shared_with=request.user)
    return render(request, 'file_sharing_app/file_list.html', {'user_files': user_files, 'shared_files': shared_files})

@login_required
def share_file(request, file_id):
    if request.method == 'POST':
        file_to_share = FileUpload.objects.get(pk=file_id)
        file_to_share.shared_with.add(request.user)
    return redirect('file_list')

@login_required
def upload_file(request):
    if request.method == 'POST':
        FileUpload.objects.create(user=request.user, file=request.FILES['file'])
    return redirect('file_list')

@login_required
def search_users(request):
    query = request.GET.get('q')
    if query:
        results = User.objects.filter(Q(username__icontains=query) | Q(email__icontains=query))
    else:
        results = []
    return render(request, 'file_sharing_app/search_results.html', {'results': results})

@login_required
def display_shared_files(request, user_id):
    shared_files = FileUpload.objects.filter(shared_with=user_id)
    return render(request, 'file_sharing_app/shared_files.html', {'shared_files': shared_files})
