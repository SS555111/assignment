# your_app_name/models.py
from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    # Add other profile fields as needed

class FileUpload(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    file = models.FileField(upload_to='uploads/')
    shared_with = models.ManyToManyField(User, related_name='shared_with', blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
